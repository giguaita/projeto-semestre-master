
export const callWorks = [
  {
    id:'13',
    name:'OBRA EXEMPLO A',
    description: 'Descrição da Obra A'
  },
  {
    id:'14',
    name:'OBRA EXEMPLO B',
    description: 'Descrição da Obra B',
  },
  {
    id:'15',
    name:'OBRA EXEMPLO C',
    description: 'Descrição da Obra C'
  },
  {
    id:'16',
    name:'OBRA EXEMPLO D',
    description: 'Descrição da Obra D'
  },
  {
    id:'17',
    name:'OBRA EXEMPLO E',
    description: 'Descrição da Obra E'
  },
  {
    id:'18',
    name:'OBRA EXEMPLO F',
    description: 'Descrição da Obra F'
  },
  {
    id:'19',
    name:'OBRA EXEMPLO G',
    description: 'Descrição da Obra G'
  },
  {
    id:'20',
    name:'OBRA EXEMPLO H',
    description: 'Descrição da Obra H'
  },
  {
    id:'21',
    name:'OBRA EXEMPLO I',
    description: 'Descrição da Obra I'
  },

]



